with open("dictionary.txt") as f:
  words = set(f.read().strip().split("\n"))