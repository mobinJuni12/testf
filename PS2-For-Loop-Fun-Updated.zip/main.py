# Part 1
for i in range(5):
  for j in range(1,6):
    print(j, end="")
  print()

# Part 2
for i in range(5):
  for j in range(5,0,-1):
    print(j, end="")
  print()

# Part 3
for i in range(5):
  for j in range(1,6):
    print(j + i, end="")
  print()

# Part 4
for i in range(1,6):
  for j in range(1, i+1):
    print(j, end="")
  print()

# Part 5
for i in range(5,0,-1):
  for j in range(1, i+1):
    print(j, end="")
  print()